export const handler = async (event) => {
  console.log({ event });
};
